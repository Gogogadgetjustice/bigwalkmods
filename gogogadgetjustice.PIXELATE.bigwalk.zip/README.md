# Pixelate

Pixelate is a client-side mod for Big Walk that provides a pixelated aesthetic with optional custom color tint filters and 4:3 letterboxing.  

Fully configurable with live hotkeys to cycle through color filters and toggle the pixelation effect in real-time.

---
## Controls

Swap filters and toggle settings directly while playing:

F10: Toggle the mod on and off.  
O: Cycle backward to the previous color tint.  
P: Cycle forward to the next color tint.  

## Features

* **Color Tints**: Includes 32 palette filters with Default, GameBoy, VirtualBoy, Amber, HighContrastNeon, C64, AppleII, GameGear, PocketCamera, Microvision, CyberNeonPink, MatrixCode, PlasmaBlue, ToxicWaste, EventHorizon, SepiaTone, Vaporwave, SunsetBleed, Midnight, Infrared, NightVision, Sonar, Blueprint, CRTStrayLight, GlitchStatic, ShaolinGold, ShogunGreen, BloodSplatter, TenzinMonk, CREAM, LiquidSword, BobbyDigital, IronMic, LoudRecords, VHSBleed, BootlegCCTV, Gravediggaz. You can tell when an album cover for the icon had been decided.

* **Overlay Styles**: Toggle between Scanlines, LCD Grid, or clean pixelation. 
 
* **Hotkey Controls**: Cycle through filters on the fly without breaking your game flow.

* **Aspect Ratio Options**: Toggle 4:3 letterboxing

---

### Configuration Settings

Fine-tune your setup in your config file (BepInEx/config/com.gogogadgetjustice.bigwalkpixelate.cfg):
- Divisor: Adjusts pixel blockiness (higher numbers equal lower render resolution).  
- EnabledOnStart: Set whether the mod defaults to active when starting the game.  ColorTint: Set your default color palette preference (e.g., VirtualBoy, GameBoy, C64).  
- OverlayStyle: Choose between None, Scanlines, or LCDGrid.  
- OverlayIntensity: Adjust how dark the scanlines or LCD grid lines appear on screen.  
- Force4x3Ratio: Enable black side pillars to simulate a classic 4:3 display aspect ratio.  

* This is easier with [ModSettingsMenu](https://thunderstore.io/c/big-walk/p/Ice_Box_Studio_BigWalk/ModSettingsMenu/).

------------------------------
## Requirements

- [BepInExPack_IL2CPP](https://thunderstore.io/c/big-walk/p/BepInEx/BepInExPack_IL2CPP/)

------------------------------
## digital tip jar. 
Thanks for supporting via [Ko-fi](https://ko-fi.com/gogogadgetjustice/)
 
## TO DO, MAYBE

* Maybe add dithering support for  1-bit display styles.
* Maybe customizable RGB color profiles saved via config.
* Maybe dynamic color tint swapping based on game events or environment.
* Maybe some actual shaders and more complicated things
* Maybe make the tint palettes more distinctive.

## License 
CC BY-NC (Attribution-NonCommercial) with a Skiwsgaard non-commerical fishng license addendum

Reach out if you do something cool with this. I want to hear about cool things.