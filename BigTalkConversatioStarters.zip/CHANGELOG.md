# Changelog

## 1.0.0
- Initial public release. 
- 100 questions! Chat or whiteboards! Limitless possibilities!
- Including all 36 questions to fall in love! 
- Folks, we gonna see some Big Walk babies by 2028. 