# Big Talk: Conversation Starters

Big Talk feeds engaging questions right to your whiteboard signs or live chat. Skip the awkward silence and give everyone something real to discuss.

Pick a category, get a conversation started.

## What it does

You can either have automatically rewrite all the starting whiteboard signs with questions, or ask questions one at a time via chat.

![Written words and chat both.](https://cdn.vixen.link/62v9gr/example.png)

- Four question categories, minimum 20 questions each: 
  **Big Talk** (philosophical/values),
  **Normal** (small talk), 
  **Magic** (fantasy/mystical fun) 
  **36 Questions to fall in love** [All of them from Mandy Len Catron's article on Arthur Aron ](https://www.nytimes.com/2015/01/11/style/modern-love-to-fall-in-love-with-anyone-do-this.html) 
  
- Deals questions onto the game's 3 usable whiteboard signs (left/center/
  right, near the start), or sends one question straight to the real in-game chat.
- Everything runs through the game's own real systems - no fake UI, no
  custom networking. Chat messages and sign text look completely normal to
  everyone else, modded or not.
  
- Modder Bonus: Left in a dev tool to gather class names and props in the bepin log. 

## Controls

| Key | Action |
|---|---|
| `B` | Set Category: Big Talk |
| `N` | Set Category: Normal (small talk) |
| `M` | Set Category: Magic/Fantasy themed |
| `L` | Set Category: 36 Questions |
| `C` | Asks one question from the current category to chat |
| `X` | Deal a fresh question from the current category onto the 3 usable signs |
| `F7` | Dev tool: raycast + dump every component's real class name on whatever you're looking at |
| `F9` | Dev tool: scan the scene for prop-like objects, grouped by name with counts |

## Known limitations

- Borrows the existing signs (rewriting their text) for ease of use. You'll have to retype your funny inside jokes.
- Signs have a **128-character limit** so questions lack followups. I believe in you though.
- When you hit C to ask a single question via chat, it appears to you in a grey box. It appears as normal chat text to everyone else. This makes it a lot easier for you to read honestly. 
- Chumps could spam questions. Please don't do that. Remember the kick button for any sad malcontents trying to ruin a good chat and change your password after.
- It tries to limit repeat questions. Use chat if you want to take it slow. There's 96 total plus 4 reminder questions about the following.

## Bigger Walk
Want hundreds of questions per category instead of twenty? Less questions but more categories? Custom sets tailored to your group or stream? A sign teleport button for convenience? 

Over on my [Ko-fi](https://ko-fi.com/gogogadgetjustice/), you can support me and receive access to Bigger Talk. Instead of 20 questions per category, there can be hundreds. I can even customzie questions and categories for you within a couple days. Let's talk.

Bigger Walk also includes a teleport key for the three signs. They float in the air if they were hanging when you called them. They fall on the ground funny if you last left them laying around. 

I left the Teleporting Whiteboards out of this release because it's too exploitable to cheese the silent room puzzles. The intent is conversation, not puzzle speedrunning. 

Sure is nice not to have to carry them around though. 

![You know.](https://cdn.vixen.link/n6hym3/theroom.png)


## License 
CC BY-NC (Attribution-NonCommercial) with a Skiwsgaard non-commerical fishng license addendum

Reach out if you do something cool with this. I want to hear about cool things.